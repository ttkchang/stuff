<template>
  <div class="home">
    <h1>Vue User Groups</h1>
    <h2>A simple application demonstrating login and user groups</h2>
  </div>
</template>

<script>
export default {}
</script>

<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>