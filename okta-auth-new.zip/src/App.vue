<template>
   <div id="app">
    <button v-on:click='login' v-if="!activeUser"> Login </button>
    <button v-on:click='logout' v-if="activeUser"> Logout </button>
    <router-view/>
  </div>
</template>

<script>
import { defineComponent } from 'vue'

export default defineComponent ({
  name: 'app',
  data () {
    return {
      activeUser: null
    }
  },
  async created () {
    await this.refreshActiveUser()
  },
  watch: {
    // everytime a route is changed refresh the activeUser
    '$route': 'refreshActiveUser'
  },
  methods: {
    login () {
      this.$auth.signInWithRedirect()
      this.$router.push('/loggedin')
    },
    async refreshActiveUser () {
      this.activeUser = await this.$auth.getUser()
    },
    async logout () {
      await this.$auth.signOut()
      await this.refreshActiveUser()
      this.$router.push('/loggedout')
    }
  }
})
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 50px;
}
</style>
