import { createRouter, createWebHistory } from 'vue-router'
import { navigationGuard , LoginCallback } from '@okta/okta-vue'
import LoggedOut from '@/components/LoggedOut'
import LoggedIn from '@/components/LoggedIn'
// Vue.use(VueRouter)

const routes = [
  {
    path: '/loggedout',
    name: 'LoggedOut',
    component: LoggedOut
  },
  {
    path: '/login/callback',
    component: LoginCallback
  },
  {
    path:'/loggedin',
    name: 'Loggedin',
    component: LoggedIn,
    meta: {
      requiresAuth: true
    }
  },
  {
    path:'/',
    name: 'LoggedIn',
    component: LoggedIn,
  }
  
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

router.beforeEach(navigationGuard)

export default router
