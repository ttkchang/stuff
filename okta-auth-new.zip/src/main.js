import  {createApp} from 'vue'
import { OktaAuth } from '@okta/okta-auth-js'
import OktaVue from '@okta/okta-vue'

import App from './App.vue'
import router from './router'

// Vue.config.productionTip = false

const oktaAuth = new OktaAuth({
  issuer: 'https://dev-33510342.okta.com/oauth2/default',
  clientId: '0oa29wwcr4skk5gce5d7',
  redirectUri: 'http://localhost:8080/login/callback',
  scopes: ['openid', 'profile', 'email']
})
// app.use(OktaVue, { oktaAuth })

const app = createApp(App)
app.use(OktaVue, { oktaAuth })
app.use(router)
app.mount('#app')

// const app = new Vue({
//   router,
//   render: function (h) { return h(App) }
// })
// app.use(OktaVue, { oktaAuth })
// app.mount('#app')
