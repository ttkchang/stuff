const authClient = new OktaAuth({
    issuer: 'https://dev-33510342.okta.com/oauth2/default',
    clientId: '0oa29wwcr4skk5gce5d7',
    redirectUri: 'http://localhost:8080/'
})

$(document).ready(async function(){
    if (await authClient.isLoginRedirect()) {
        try {
          await authClient.handleLoginRedirect();
        } catch (e) {
          console.log(e)
        }
    } 
    if(await authClient.isAuthenticated()) {
        $('#login-button').addClass('d-none')
        $('#logout-button').removeClass('d-none')
        let idToken = await authClient.getIdToken();
        $('#idToken').text(idToken)
        let accessToken = await authClient.getAccessToken();
        $('#accessToken').text(accessToken)
        let user = await authClient.getUser();
        $('#userInfo').text(JSON.stringify(user))
        $('#Detais').removeClass('d-none')
    } else {
        $('#login-button').removeClass('d-none')
        $('#logout-button').addClass('d-none')
    }
})

async function login() {
    if (await authClient.isLoginRedirect()) {
        try {
          await authClient.handleLoginRedirect();
        } catch (e) {
          console.log(e)
        }
      } else if (!await authClient.isAuthenticated()) {
        await authClient.signInWithRedirect({originalUri: `${window.location.origin}/`});
      } else {
        $('#login-button').addClass('d-none')
        $('#logout-button').removeClass('d-none')
        let idToken = await authClient.getIdToken();
        $('#idToken').text(idToken)
        let accessToken = await authClient.getAccessToken();
        $('#accessToken').text(accessToken)
        let user = await authClient.getUser();
        $('#userInfo').text(JSON.stringify(user))
        $('#Detais').removeClass('d-none')
      }
}

async function logout() {
    await authClient.signOut({postLogoutRedirectUri: `${window.location.origin}/`})
    $('#Detais').addClass('d-none')
    $('#logout-button').addClass('d-none')
    $('#login-button').removeClass('d-none')
}