<template>
  <div class="contact">
    <h1>This is a contact page</h1>
  </div>
</template>
